### cookieops-backend/app/main.py

from fastapi import FastAPI,Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.utils import get_openapi
import asyncio

from app.auth.routes import auth_backend, fastapi_users
from app.models.user import User
from app.api import shift_routes, task_routes
from app.db import create_db_and_tables
from app.schemas.user import UserRead, UserCreate
from app.models import shift, task, submission, user
from app.auth.routes import get_current_user
app = FastAPI()

# ✅ Swagger Bearer token support for "Authorize" button
def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    openapi_schema = get_openapi(
        title="CookieOps API",
        version="1.0.0",
        description="API for managing cookie biz shifts, tasks, and users.",
        routes=app.routes,
    )
    openapi_schema["components"]["securitySchemes"] = {
        "BearerAuth": {
            "type": "http",
            "scheme": "bearer",
            "bearerFormat": "JWT"
        }
    }
    for path in openapi_schema["paths"].values():
        for operation in path.values():
            operation["security"] = [{"BearerAuth": []}]
    app.openapi_schema = openapi_schema
    return app.openapi_schema

app.openapi = custom_openapi

# ✅ Auth routes
app.include_router(
    fastapi_users.get_auth_router(auth_backend),
    prefix="/auth/jwt",
    tags=["auth"]
)

app.include_router(
    fastapi_users.get_register_router(UserRead, UserCreate),
    prefix="/auth/users",
    tags=["auth"]
)

app.include_router(
    fastapi_users.get_users_router(UserRead, UserCreate),
    prefix="/auth/users",
    tags=["auth"]
)

# ✅ Allow frontend dev (CORS)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In prod, restrict this!
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/whoami")
async def whoami(user=Depends(get_current_user)):
    print("✅ User Authenticated:", user)
    return user

# ✅ DB setup on startup
@app.on_event("startup")
def on_startup():
    asyncio.create_task(create_db_and_tables())

# ✅ Core app routers
app.include_router(shift_routes.router, prefix="/shifts")
app.include_router(task_routes.router, prefix="/tasks")
