from sqlalchemy import Column, String, ForeignKey, Enum
from sqlalchemy.orm import relationship
from app.models.base import Base
import uuid
import enum

class InputType(str, enum.Enum):
    checkbox = "checkbox"
    text = "text"
    photo = "photo"

class TaskTemplate(Base):
    __tablename__ = "task_templates"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    title = Column(String, nullable=False)
    description = Column(String, nullable=True)

    items = relationship("TaskItem", back_populates="template")

class TaskItem(Base):
    __tablename__ = "task_items"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    prompt = Column(String, nullable=False)
    input_type = Column(Enum(InputType), default=InputType.checkbox)

    template_id = Column(String, ForeignKey("task_templates.id"))
    template = relationship("TaskTemplate", back_populates="items")
