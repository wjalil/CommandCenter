from sqlalchemy import Column, String, ForeignKey, Text
from sqlalchemy.orm import relationship
from app.models.base import Base
import uuid

class TaskSubmission(Base):
    __tablename__ = "task_submissions"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    value = Column(Text, nullable=False)

    shift_id = Column(String, ForeignKey("shifts.id"))
    worker_id = Column(String, ForeignKey("users.id"))
    task_item_id = Column(String, ForeignKey("task_items.id"))

    shift = relationship("Shift", back_populates="submissions")
