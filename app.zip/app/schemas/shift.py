from pydantic import BaseModel
from datetime import datetime
from typing import Optional

class ShiftBase(BaseModel):
    label: str
    start_time: datetime
    end_time: datetime

class ShiftCreate(ShiftBase):
    pass

class ShiftRead(ShiftBase):
    id: str
    date: datetime
    is_filled: bool
    assigned_worker_id: Optional[str]

    class Config:
        from_attributes = True
