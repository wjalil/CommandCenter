from pydantic import BaseModel
from typing import List, Optional
from enum import Enum

class InputType(str, Enum):
    checkbox = "checkbox"
    text = "text"
    photo = "photo"

class TaskItemBase(BaseModel):
    prompt: str
    input_type: InputType = InputType.checkbox

class TaskItemCreate(TaskItemBase):
    pass

class TaskItemRead(TaskItemBase):
    id: str

    class Config:
        from_attributes = True

class TaskTemplateBase(BaseModel):
    title: str
    description: Optional[str] = None

class TaskTemplateCreate(TaskTemplateBase):
    items: List[TaskItemCreate]

class TaskTemplateRead(TaskTemplateBase):
    id: str
    items: List[TaskItemRead]

    class Config:
        from_attributes = True
