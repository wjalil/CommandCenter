from sqlalchemy.ext.asyncio import AsyncSession
from app.models.task import TaskTemplate, TaskItem
from app.schemas.task import TaskTemplateCreate
import uuid

async def create_task_template(db: AsyncSession, template: TaskTemplateCreate):
    new_template = TaskTemplate(
        id=str(uuid.uuid4()),
        title=template.title,
        description=template.description
    )
    db.add(new_template)
    await db.flush()  # Get template ID before adding items

    for item in template.items:
        task_item = TaskItem(
            id=str(uuid.uuid4()),
            prompt=item.prompt,
            input_type=item.input_type,
            template_id=new_template.id
        )
        db.add(task_item)

    await db.commit()
    await db.refresh(new_template)
    return new_template

async def get_all_task_templates(db: AsyncSession):
    result = await db.execute(select(TaskTemplate))
    return result.scalars().all()
