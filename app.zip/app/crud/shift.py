from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy import update
from app.models.shift import Shift
from app.schemas.shift import ShiftCreate
import uuid

async def create_shift(db: AsyncSession, shift: ShiftCreate):
    new_shift = Shift(
        id=str(uuid.uuid4()),
        label=shift.label,
        start_time=shift.start_time,
        end_time=shift.end_time,
    )
    db.add(new_shift)
    await db.commit()
    await db.refresh(new_shift)
    return new_shift

async def get_all_shifts(db: AsyncSession):
    result = await db.execute(select(Shift))
    return result.scalars().all()

async def claim_shift(db: AsyncSession, shift_id: str, user_id: str):
    stmt = (
        update(Shift)
        .where(Shift.id == shift_id, Shift.is_filled == False)
        .values(assigned_worker_id=user_id, is_filled=True)
        .execution_options(synchronize_session="fetch")
    )
    await db.execute(stmt)
    await db.commit()
