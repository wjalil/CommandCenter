from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List

from app.schemas.task import TaskTemplateCreate, TaskTemplateRead
from app.crud import task as task_crud
from app.db import get_db

router = APIRouter()

@router.post("/", response_model=TaskTemplateRead)
async def create_task_template(template: TaskTemplateCreate, db: AsyncSession = Depends(get_db)):
    return await task_crud.create_task_template(db, template)

@router.get("/", response_model=List[TaskTemplateRead])
async def list_templates(db: AsyncSession = Depends(get_db)):
    return await task_crud.get_all_task_templates(db)
