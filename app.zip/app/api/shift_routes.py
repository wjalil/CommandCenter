from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List

from app.schemas.shift import ShiftCreate, ShiftRead
from app.crud import shift as shift_crud
from app.db import get_db

router = APIRouter()

@router.post("/", response_model=ShiftRead)
async def create_shift(shift: ShiftCreate, db: AsyncSession = Depends(get_db)):
    return await shift_crud.create_shift(db, shift)

@router.get("/", response_model=List[ShiftRead])
async def list_shifts(db: AsyncSession = Depends(get_db)):
    return await shift_crud.get_all_shifts(db)

@router.post("/{shift_id}/claim")
async def claim_shift(shift_id: str, user_id: str, db: AsyncSession = Depends(get_db)):
    await shift_crud.claim_shift(db, shift_id, user_id)
    return {"message": "Shift claimed"}
