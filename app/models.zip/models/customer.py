from sqlalchemy import Column, String, ForeignKey,Integer
from app.models.base import Base
from sqlalchemy.orm import relationship
import uuid

class Customer(Base):
    __tablename__ = "customers"
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String, nullable=False)
    pin_code = Column(String, nullable=False)
    tenant_id = Column(Integer, ForeignKey("tenants.id"))
    tenant = relationship("Tenant", back_populates="customers")
