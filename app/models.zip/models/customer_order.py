from sqlalchemy import Column, String, DateTime, ForeignKey, Integer
from sqlalchemy.orm import relationship
from datetime import datetime
from app.models.base import Base
import uuid
from app.models.tenant import Tenant

class CustomerOrder(Base):
    __tablename__ = "customer_orders"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    customer_id = Column(String, ForeignKey("customers.id"))
    timestamp = Column(DateTime, default=datetime.utcnow)
    items = relationship("OrderItem", back_populates="order")

    tenant_id = Column(Integer, ForeignKey("tenants.id"))
    tenant = relationship("Tenant", back_populates="customer_orders")

class OrderItem(Base):
    __tablename__ = "order_items"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    order_id = Column(String, ForeignKey("customer_orders.id"))
    menu_item_id = Column(String, ForeignKey("menu_items.id"))
    quantity = Column(Integer, nullable=False)

    order = relationship("CustomerOrder", back_populates="items")
