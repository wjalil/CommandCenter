from fastapi import Request, Form, Depends,APIRouter
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from app.db import get_db
from app.models.customer import Customer

templates = Jinja2Templates(directory="app/templates")

router = APIRouter()

@router.get("/customer/login", response_class=HTMLResponse)
async def customer_login_page(request: Request):
    return templates.TemplateResponse("login_customer.html", {"request": request})

@router.post("/customer/login", response_class=HTMLResponse)
async def customer_login_post(
    request: Request,
    pin_code: str = Form(...),
    db: AsyncSession = Depends(get_db)
):
    result = await db.execute(select(Customer).where(Customer.pin_code == pin_code))
    customer = result.scalar_one_or_none()

    if customer:
        request.session["user_id"] = customer.id
        request.session["role"] = "customer"
        request.session["tenant_id"] = customer.tenant_id 
        return RedirectResponse(f"/customer/menu", status_code=302)

    return templates.TemplateResponse("login_customer.html", {
        "request": request,
        "error": "Invalid PIN. Please try again.",
    })
